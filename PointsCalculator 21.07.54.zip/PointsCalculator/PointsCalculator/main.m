//
//  main.m
//  PointsCalculator
//
//  Created by Alan Leonard on 19/07/2014.
//  Copyright (c) 2014 careersportal. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
