//
//  Higher.m
//  PointsCalculator
//
//  Created by Alan Leonard on 19/07/2014.
//  Copyright (c) 2014 careersportal. All rights reserved.
//

#import "Higher.h"

@implementation Higher

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
