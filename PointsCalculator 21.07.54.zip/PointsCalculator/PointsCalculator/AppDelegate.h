//
//  AppDelegate.h
//  PointsCalculator
//
//  Created by Alan Leonard on 19/07/2014.
//  Copyright (c) 2014 careersportal. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) NSMutableArray *CollectPoints3;
@property (strong, nonatomic) NSMutableArray *sortedArray;
@property (strong, nonatomic) NSMutableArray *SixArray;
@property (strong, nonatomic) NSMutableArray *LastTry;



@end
